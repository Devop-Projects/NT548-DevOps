# envs/eks/backend.tf
terraform {
  backend "s3" {}
}

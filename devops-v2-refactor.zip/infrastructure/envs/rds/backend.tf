# envs/rds/backend.tf
terraform {
  backend "s3" {}
}

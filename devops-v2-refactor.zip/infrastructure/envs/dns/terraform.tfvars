# envs/dns/terraform.tfvars

# ⚠️ Đổi domain của bạn
domain_name        = "vantai.click"
subdomain          = "task-manager"
create_hosted_zone = false

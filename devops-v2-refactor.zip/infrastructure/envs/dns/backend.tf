# envs/dns/backend.tf
terraform {
  backend "s3" {}
}

# envs/dev/backend.tf
#
# Partial backend — config truyền qua -backend-config flag.
# Xem infrastructure/backend-config.hcl + Makefile target tf-init-all.

terraform {
  backend "s3" {}
}

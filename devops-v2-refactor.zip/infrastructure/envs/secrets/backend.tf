# envs/secrets/backend.tf
terraform {
  backend "s3" {}
}
